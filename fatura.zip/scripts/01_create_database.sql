-- Criação do banco de dados Invoice Delphi
CREATE DATABASE IF NOT EXISTS invoice_delphi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE invoice_delphi;

-- Tabela de usuários
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de clientes
CREATE TABLE clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    cnpj VARCHAR(18),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(2),
    zip VARCHAR(10),
    phone VARCHAR(20),
    email VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de faturas
CREATE TABLE invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    user_id INT NOT NULL,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    term_days INT DEFAULT 30,
    demonstrative TEXT,
    
    -- Dados de embarque
    mbl VARCHAR(100),
    hbl VARCHAR(100),
    origin VARCHAR(100),
    destination VARCHAR(100),
    incoterm ENUM('FOB', 'CIF', 'EXW', 'DDP', 'DAP') DEFAULT 'FOB',
    transport_mode ENUM('MARITIMO', 'AEREO', 'RODOVIARIO', 'FERROVIARIO') DEFAULT 'MARITIMO',
    exporter VARCHAR(255),
    gross_weight DECIMAL(10,3),
    cubic_weight DECIMAL(10,3),
    eto DATE,
    eta DATE,
    po_number VARCHAR(100),
    invoice_ref VARCHAR(100),
    
    -- Totais e fechamento
    total_receivable DECIMAL(15,2) DEFAULT 0,
    total_refund DECIMAL(15,2) DEFAULT 0,
    eur_usd_rate DECIMAL(8,4) DEFAULT 1,
    closing_term TEXT,
    
    status ENUM('DRAFT', 'SENT', 'PAID', 'CANCELLED') DEFAULT 'DRAFT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de itens da fatura
CREATE TABLE invoice_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    description TEXT NOT NULL,
    currency ENUM('BRL', 'USD', 'EUR') DEFAULT 'BRL',
    amount DECIMAL(15,2) NOT NULL,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- Índices para performance
CREATE INDEX idx_invoices_client ON invoices(client_id);
CREATE INDEX idx_invoices_user ON invoices(user_id);
CREATE INDEX idx_invoices_date ON invoices(issue_date);
CREATE INDEX idx_invoice_items_invoice ON invoice_items(invoice_id);
