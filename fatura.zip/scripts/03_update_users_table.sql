-- Adicionar campo last_login na tabela users
ALTER TABLE users ADD COLUMN last_login TIMESTAMP NULL;
