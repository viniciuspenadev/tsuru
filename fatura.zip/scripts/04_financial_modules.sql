-- Criar tabelas para os novos módulos financeiros

-- Tabela de valores recebidos (o que o cliente pagou)
CREATE TABLE invoice_received_values (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    description TEXT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    currency ENUM('BRL', 'USD', 'EUR') DEFAULT 'BRL',
    received_date DATE NOT NULL,
    payment_method VARCHAR(100),
    bank_reference VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- Tabela de valores pagos (despesas reais)
CREATE TABLE invoice_paid_values (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    description TEXT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    currency ENUM('BRL', 'USD', 'EUR') DEFAULT 'BRL',
    paid_date DATE NOT NULL,
    payment_method VARCHAR(100),
    supplier VARCHAR(255),
    document_number VARCHAR(100),
    category ENUM('FRETE', 'TAXA', 'DESPACHANTE', 'ARMAZENAGEM', 'OUTROS') DEFAULT 'OUTROS',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- Adicionar campos de controle financeiro na tabela invoices
ALTER TABLE invoices ADD COLUMN total_received DECIMAL(15,2) DEFAULT 0;
ALTER TABLE invoices ADD COLUMN total_paid DECIMAL(15,2) DEFAULT 0;
ALTER TABLE invoices ADD COLUMN financial_status ENUM('PENDING', 'PARTIAL', 'COMPLETED', 'LOSS') DEFAULT 'PENDING';

-- Índices para performance
CREATE INDEX idx_received_values_invoice ON invoice_received_values(invoice_id);
CREATE INDEX idx_paid_values_invoice ON invoice_paid_values(invoice_id);
CREATE INDEX idx_received_values_date ON invoice_received_values(received_date);
CREATE INDEX idx_paid_values_date ON invoice_paid_values(paid_date);
