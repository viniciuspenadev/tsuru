-- Renomear a tabela atual de itens para valores recebidos
RENAME TABLE invoice_items TO invoice_received_items;

-- Criar nova tabela para valores pagos (mesma estrutura)
CREATE TABLE invoice_paid_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    description TEXT NOT NULL,
    currency ENUM('BRL', 'USD', 'EUR') DEFAULT 'BRL',
    amount DECIMAL(15,2) NOT NULL,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- Criar índice para performance
CREATE INDEX idx_paid_items_invoice ON invoice_paid_items(invoice_id);

-- Atualizar campos na tabela invoices para refletir a nova estrutura
ALTER TABLE invoices 
ADD COLUMN total_paid_items DECIMAL(15,2) DEFAULT 0 AFTER total_refund;
