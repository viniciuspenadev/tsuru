-- Inserir usuário administrador padrão
INSERT INTO users (name, email, password) VALUES 
('Administrador', 'admin@invoicedelphi.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
-- Senha: password

-- Inserir alguns clientes de exemplo
INSERT INTO clients (name, cnpj, address, city, state, zip, phone, email) VALUES 
('Empresa ABC Ltda', '12.345.678/0001-90', 'Rua das Flores, 123', 'São Paulo', 'SP', '01234-567', '(11) 9999-8888', 'contato@empresaabc.com'),
('Comércio XYZ S.A.', '98.765.432/0001-10', 'Av. Paulista, 1000', 'São Paulo', 'SP', '01310-100', '(11) 8888-7777', 'financeiro@comercioxyz.com'),
('Indústria DEF ME', '11.222.333/0001-44', 'Rua Industrial, 500', 'Guarulhos', 'SP', '07000-000', '(11) 7777-6666', 'compras@industriadef.com');
