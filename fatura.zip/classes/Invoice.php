<?php
require_once __DIR__ . '/../config/database.php';

class Invoice {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function create($data) {
        try {
            $this->db->beginTransaction();
            
            // Gerar número da fatura
            $invoiceNumber = $this->generateInvoiceNumber();
            
            // Inserir fatura
            $sql = "INSERT INTO invoices (
                client_id, user_id, invoice_number, issue_date, due_date, term_days, 
                demonstrative, mbl, hbl, origin, destination, incoterm, transport_mode,
                exporter, gross_weight, cubic_weight, eto, eta, po_number, invoice_ref,
                total_receivable, total_refund, total_paid_items, eur_usd_rate, closing_term, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $data['client_id'],
                $_SESSION['user_id'],
                $invoiceNumber,
                $data['issue_date'],
                $data['due_date'],
                $data['term_days'],
                $data['demonstrative'],
                $data['mbl'],
                $data['hbl'],
                $data['origin'],
                $data['destination'],
                $data['incoterm'],
                $data['transport_mode'],
                $data['exporter'],
                $data['gross_weight'],
                $data['cubic_weight'],
                $data['eto'],
                $data['eta'],
                $data['po_number'],
                $data['invoice_ref'],
                $data['total_receivable'],
                $data['total_refund'],
                $data['total_paid_items'],
                $data['eur_usd_rate'],
                $data['closing_term'],
                $data['status'] ?? 'DRAFT'
            ]);
            
            $invoiceId = $this->db->lastInsertId();
            
            // Inserir itens recebidos
            if (!empty($data['received_items'])) {
                $this->saveReceivedItems($invoiceId, $data['received_items']);
            }
            
            // Inserir itens pagos
            if (!empty($data['paid_items'])) {
                $this->savePaidItems($invoiceId, $data['paid_items']);
            }
            
            $this->db->commit();
            return $invoiceId;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
    
    public function update($id, $data) {
        try {
            $this->db->beginTransaction();
            
            // Atualizar fatura
            $sql = "UPDATE invoices SET 
                client_id = ?, issue_date = ?, due_date = ?, term_days = ?, 
                demonstrative = ?, mbl = ?, hbl = ?, origin = ?, destination = ?, 
                incoterm = ?, transport_mode = ?, exporter = ?, gross_weight = ?, 
                cubic_weight = ?, eto = ?, eta = ?, po_number = ?, invoice_ref = ?,
                total_receivable = ?, total_refund = ?, total_paid_items = ?, eur_usd_rate = ?, 
                closing_term = ?, status = ?
                WHERE id = ?";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $data['client_id'],
                $data['issue_date'],
                $data['due_date'],
                $data['term_days'],
                $data['demonstrative'],
                $data['mbl'],
                $data['hbl'],
                $data['origin'],
                $data['destination'],
                $data['incoterm'],
                $data['transport_mode'],
                $data['exporter'],
                $data['gross_weight'],
                $data['cubic_weight'],
                $data['eto'],
                $data['eta'],
                $data['po_number'],
                $data['invoice_ref'],
                $data['total_receivable'],
                $data['total_refund'],
                $data['total_paid_items'],
                $data['eur_usd_rate'],
                $data['closing_term'],
                $data['status'] ?? 'DRAFT',
                $id
            ]);
            
            // Remover itens existentes e inserir novos
            $this->db->prepare("DELETE FROM invoice_received_items WHERE invoice_id = ?")->execute([$id]);
            $this->db->prepare("DELETE FROM invoice_paid_items WHERE invoice_id = ?")->execute([$id]);
            
            if (!empty($data['received_items'])) {
                $this->saveReceivedItems($id, $data['received_items']);
            }
            
            if (!empty($data['paid_items'])) {
                $this->savePaidItems($id, $data['paid_items']);
            }
            
            $this->db->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
    
    public function clone($id) {
        $invoice = $this->findById($id);
        if (!$invoice) {
            return false;
        }
        
        // Remover campos únicos e IDs
        unset($invoice['id'], $invoice['invoice_number'], $invoice['created_at'], $invoice['updated_at']);
        
        // Atualizar data de emissão para hoje
        $invoice['issue_date'] = date('Y-m-d');
        $invoice['due_date'] = date('Y-m-d', strtotime('+' . $invoice['term_days'] . ' days'));
        $invoice['status'] = 'DRAFT';
        
        return $this->create($invoice);
    }
    
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM invoices WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    public function findById($id) {
        $sql = "SELECT i.*, c.name as client_name, c.cnpj, c.address, c.city, c.state, c.zip, c.phone, c.email as client_email
                FROM invoices i 
                JOIN clients c ON i.client_id = c.id 
                WHERE i.id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        $invoice = $stmt->fetch();
        
        if ($invoice) {
            $invoice['received_items'] = $this->getReceivedItems($id);
            $invoice['paid_items'] = $this->getPaidItems($id);
        }
        
        return $invoice;
    }
    
    public function findAll($limit = 50, $offset = 0, $filters = []) {
        $sql = "SELECT i.*, c.name as client_name 
                FROM invoices i 
                JOIN clients c ON i.client_id = c.id 
                WHERE 1=1";
        $params = [];
        
        if (!empty($filters['client_id'])) {
            $sql .= " AND i.client_id = ?";
            $params[] = $filters['client_id'];
        }
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND i.issue_date >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND i.issue_date <= ?";
            $params[] = $filters['date_to'];
        }
        
        if (!empty($filters['status'])) {
            $sql .= " AND i.status = ?";
            $params[] = $filters['status'];
        }
        
        $sql .= " ORDER BY i.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    private function saveReceivedItems($invoiceId, $items) {
        $sql = "INSERT INTO invoice_received_items (invoice_id, description, currency, amount, sort_order) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        
        foreach ($items as $index => $item) {
            $stmt->execute([
                $invoiceId,
                $item['description'],
                $item['currency'],
                $item['amount'],
                $index
            ]);
        }
    }
    
    private function savePaidItems($invoiceId, $items) {
        $sql = "INSERT INTO invoice_paid_items (invoice_id, description, currency, amount, sort_order) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        
        foreach ($items as $index => $item) {
            $stmt->execute([
                $invoiceId,
                $item['description'],
                $item['currency'],
                $item['amount'],
                $index
            ]);
        }
    }
    
    private function getReceivedItems($invoiceId) {
        $stmt = $this->db->prepare("SELECT * FROM invoice_received_items WHERE invoice_id = ? ORDER BY sort_order");
        $stmt->execute([$invoiceId]);
        return $stmt->fetchAll();
    }
    
    private function getPaidItems($invoiceId) {
        $stmt = $this->db->prepare("SELECT * FROM invoice_paid_items WHERE invoice_id = ? ORDER BY sort_order");
        $stmt->execute([$invoiceId]);
        return $stmt->fetchAll();
    }
    
    private function generateInvoiceNumber() {
        $year = date('Y');
        $month = date('m');
        
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM invoices WHERE YEAR(created_at) = ? AND MONTH(created_at) = ?");
        $stmt->execute([$year, $month]);
        $result = $stmt->fetch();
        
        $sequence = str_pad($result['count'] + 1, 4, '0', STR_PAD_LEFT);
        return "INV-{$year}{$month}-{$sequence}";
    }
}
?>
