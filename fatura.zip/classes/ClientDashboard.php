<?php
require_once __DIR__ . '/../config/database.php';

class ClientDashboard {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function getClientStats($clientId) {
        $stats = [];
        
        // Total de faturas
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM invoices WHERE client_id = ?");
        $stmt->execute([$clientId]);
        $stats['total_invoices'] = $stmt->fetch()['total'];
        
        // Valor total faturado
        $stmt = $this->db->prepare("SELECT SUM(total_receivable) as total FROM invoices WHERE client_id = ? AND status != 'CANCELLED'");
        $stmt->execute([$clientId]);
        $stats['total_billed'] = $stmt->fetch()['total'] ?? 0;
        
        // Faturas por status
        $stmt = $this->db->prepare("SELECT status, COUNT(*) as count FROM invoices WHERE client_id = ? GROUP BY status");
        $stmt->execute([$clientId]);
        $statusCounts = $stmt->fetchAll();
        foreach ($statusCounts as $status) {
            $stats['status_' . strtolower($status['status'])] = $status['count'];
        }
        
        // Faturas com vencimento próximo (7 dias)
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM invoices WHERE client_id = ? AND due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND status IN ('SENT', 'DRAFT')");
        $stmt->execute([$clientId]);
        $stats['due_soon'] = $stmt->fetch()['count'];
        
        // Faturas vencidas
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM invoices WHERE client_id = ? AND due_date < CURDATE() AND status IN ('SENT', 'DRAFT')");
        $stmt->execute([$clientId]);
        $stats['overdue'] = $stmt->fetch()['count'];
        
        // Última fatura
        $stmt = $this->db->prepare("SELECT invoice_number, issue_date, total_receivable, status FROM invoices WHERE client_id = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$clientId]);
        $stats['last_invoice'] = $stmt->fetch();
        
        return $stats;
    }
    
    public function getClientInvoices($clientId, $limit = 50, $offset = 0, $filters = []) {
        $sql = "SELECT * FROM invoices WHERE client_id = ?";
        $params = [$clientId];
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND issue_date >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND issue_date <= ?";
            $params[] = $filters['date_to'];
        }
        
        if (!empty($filters['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        }
        
        $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function countClientInvoices($clientId, $filters = []) {
        $sql = "SELECT COUNT(*) as total FROM invoices WHERE client_id = ?";
        $params = [$clientId];
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND issue_date >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND issue_date <= ?";
            $params[] = $filters['date_to'];
        }
        
        if (!empty($filters['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch()['total'];
    }
}
?>
