<?php
require_once __DIR__ . '/../config/database.php';

class InvoiceDocument {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function upload($invoiceId, $fileData, $description, $category = 'OUTROS', $notes = '') {
        try {
            // Validar arquivo
            $allowedTypes = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif'];
            $maxSize = MAX_FILE_SIZE; // 5MB definido em config.php
            
            $originalFilename = $fileData['name'];
            $fileSize = $fileData['size'];
            $tmpName = $fileData['tmp_name'];
            $mimeType = $fileData['type'];
            
            // Validar extensão
            $fileExtension = strtolower(pathinfo($originalFilename, PATHINFO_EXTENSION));
            if (!in_array($fileExtension, $allowedTypes)) {
                throw new Exception('Tipo de arquivo não permitido.');
            }
            
            // Validar tamanho
            if ($fileSize > $maxSize) {
                throw new Exception('Arquivo muito grande. Máximo permitido: ' . ($maxSize / 1024 / 1024) . 'MB');
            }
            
            // Criar diretório se não existir
            $uploadDir = UPLOAD_PATH . 'invoices/' . $invoiceId . '/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            // Gerar nome único para o arquivo
            $storedFilename = uniqid() . '_' . time() . '.' . $fileExtension;
            $fullPath = $uploadDir . $storedFilename;
            
            // Mover arquivo
            if (!move_uploaded_file($tmpName, $fullPath)) {
                throw new Exception('Erro ao salvar arquivo no servidor.');
            }
            
            // Salvar no banco de dados
            $sql = "INSERT INTO invoice_documents 
                    (invoice_id, original_filename, stored_filename, file_extension, file_size, mime_type, description, category, notes, uploaded_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute([
                $invoiceId,
                $originalFilename,
                $storedFilename,
                $fileExtension,
                $fileSize,
                $mimeType,
                $description,
                $category,
                $notes,
                $_SESSION['user_id']
            ]);
            
            if ($result) {
                return $this->db->lastInsertId();
            } else {
                // Se falhou no banco, remover arquivo
                unlink($fullPath);
                throw new Exception('Erro ao salvar informações do documento.');
            }
            
        } catch (Exception $e) {
            throw $e;
        }
    }
    
    public function getByInvoiceId($invoiceId) {
        $sql = "SELECT d.*, u.name as uploaded_by_name 
                FROM invoice_documents d 
                JOIN users u ON d.uploaded_by = u.id 
                WHERE d.invoice_id = ? 
                ORDER BY d.created_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$invoiceId]);
        return $stmt->fetchAll();
    }
    
    public function findById($id) {
        $sql = "SELECT * FROM invoice_documents WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function delete($id) {
        try {
            // Buscar informações do documento
            $document = $this->findById($id);
            if (!$document) {
                throw new Exception('Documento não encontrado.');
            }
            
            // Remover arquivo do sistema
            $filePath = UPLOAD_PATH . 'invoices/' . $document['invoice_id'] . '/' . $document['stored_filename'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            
            // Remover do banco
            $stmt = $this->db->prepare("DELETE FROM invoice_documents WHERE id = ?");
            return $stmt->execute([$id]);
            
        } catch (Exception $e) {
            throw $e;
        }
    }
    
    public function getFilePath($id) {
        $document = $this->findById($id);
        if (!$document) {
            return false;
        }
        
        $filePath = UPLOAD_PATH . 'invoices/' . $document['invoice_id'] . '/' . $document['stored_filename'];
        return file_exists($filePath) ? $filePath : false;
    }
}
?>
