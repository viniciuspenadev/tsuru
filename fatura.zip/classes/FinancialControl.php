<?php
require_once __DIR__ . '/../config/database.php';

class FinancialControl {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    // Valores Recebidos
    public function addReceivedValue($invoiceId, $data) {
        $sql = "INSERT INTO invoice_received_values 
                (invoice_id, description, amount, currency, received_date, payment_method, bank_reference, notes) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute([
            $invoiceId,
            $data['description'],
            $data['amount'],
            $data['currency'],
            $data['received_date'],
            $data['payment_method'],
            $data['bank_reference'],
            $data['notes']
        ]);
        
        if ($result) {
            $this->updateInvoiceTotals($invoiceId);
        }
        
        return $result;
    }
    
    public function getReceivedValues($invoiceId) {
        $stmt = $this->db->prepare("SELECT * FROM invoice_received_values WHERE invoice_id = ? ORDER BY received_date DESC");
        $stmt->execute([$invoiceId]);
        return $stmt->fetchAll();
    }
    
    public function deleteReceivedValue($id) {
        // Buscar invoice_id antes de deletar
        $stmt = $this->db->prepare("SELECT invoice_id FROM invoice_received_values WHERE id = ?");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        
        if ($result) {
            $invoiceId = $result['invoice_id'];
            $stmt = $this->db->prepare("DELETE FROM invoice_received_values WHERE id = ?");
            $deleted = $stmt->execute([$id]);
            
            if ($deleted) {
                $this->updateInvoiceTotals($invoiceId);
            }
            
            return $deleted;
        }
        
        return false;
    }
    
    // Valores Pagos
    public function addPaidValue($invoiceId, $data) {
        $sql = "INSERT INTO invoice_paid_values 
                (invoice_id, description, amount, currency, paid_date, payment_method, supplier, document_number, category, notes) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute([
            $invoiceId,
            $data['description'],
            $data['amount'],
            $data['currency'],
            $data['paid_date'],
            $data['payment_method'],
            $data['supplier'],
            $data['document_number'],
            $data['category'],
            $data['notes']
        ]);
        
        if ($result) {
            $this->updateInvoiceTotals($invoiceId);
        }
        
        return $result;
    }
    
    public function getPaidValues($invoiceId) {
        $stmt = $this->db->prepare("SELECT * FROM invoice_paid_values WHERE invoice_id = ? ORDER BY paid_date DESC");
        $stmt->execute([$invoiceId]);
        return $stmt->fetchAll();
    }
    
    public function deletePaidValue($id) {
        // Buscar invoice_id antes de deletar
        $stmt = $this->db->prepare("SELECT invoice_id FROM invoice_paid_values WHERE id = ?");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        
        if ($result) {
            $invoiceId = $result['invoice_id'];
            $stmt = $this->db->prepare("DELETE FROM invoice_paid_values WHERE id = ?");
            $deleted = $stmt->execute([$id]);
            
            if ($deleted) {
                $this->updateInvoiceTotals($invoiceId);
            }
            
            return $deleted;
        }
        
        return false;
    }
    
    // Atualizar totais da fatura
    private function updateInvoiceTotals($invoiceId) {
        // Calcular total recebido
        $stmt = $this->db->prepare("SELECT SUM(amount) as total FROM invoice_received_values WHERE invoice_id = ? AND currency = 'BRL'");
        $stmt->execute([$invoiceId]);
        $totalReceived = $stmt->fetch()['total'] ?? 0;
        
        // Calcular total pago
        $stmt = $this->db->prepare("SELECT SUM(amount) as total FROM invoice_paid_values WHERE invoice_id = ? AND currency = 'BRL'");
        $stmt->execute([$invoiceId]);
        $totalPaid = $stmt->fetch()['total'] ?? 0;
        
        // Determinar status financeiro
        $financialStatus = 'PENDING';
        if ($totalReceived > 0 && $totalPaid > 0) {
            if ($totalReceived > $totalPaid) {
                $financialStatus = 'COMPLETED'; // Lucro
            } elseif ($totalReceived < $totalPaid) {
                $financialStatus = 'LOSS'; // Prejuízo
            } else {
                $financialStatus = 'COMPLETED'; // Equilibrado
            }
        } elseif ($totalReceived > 0 || $totalPaid > 0) {
            $financialStatus = 'PARTIAL';
        }
        
        // Atualizar fatura
        $stmt = $this->db->prepare("UPDATE invoices SET total_received = ?, total_paid = ?, financial_status = ? WHERE id = ?");
        return $stmt->execute([$totalReceived, $totalPaid, $financialStatus, $invoiceId]);
    }
    
    // Relatórios
    public function getInvoiceFinancialSummary($invoiceId) {
        $stmt = $this->db->prepare("SELECT total_receivable, total_received, total_paid, financial_status FROM invoices WHERE id = ?");
        $stmt->execute([$invoiceId]);
        $invoice = $stmt->fetch();
        
        if ($invoice) {
            $invoice['profit_loss'] = $invoice['total_received'] - $invoice['total_paid'];
            $invoice['margin_percent'] = $invoice['total_received'] > 0 ? 
                (($invoice['profit_loss'] / $invoice['total_received']) * 100) : 0;
        }
        
        return $invoice;
    }
    
    public function getDashboardStats() {
        $stats = [];
        
        // Total de faturas
        $stmt = $this->db->query("SELECT COUNT(*) as total FROM invoices");
        $stats['total_invoices'] = $stmt->fetch()['total'];
        
        // Valor total faturado
        $stmt = $this->db->query("SELECT SUM(total_receivable) as total FROM invoices WHERE status != 'CANCELLED'");
        $stats['total_billed'] = $stmt->fetch()['total'] ?? 0;
        
        // Valor total recebido
        $stmt = $this->db->query("SELECT SUM(total_received) as total FROM invoices");
        $stats['total_received'] = $stmt->fetch()['total'] ?? 0;
        
        // Valor total pago
        $stmt = $this->db->query("SELECT SUM(total_paid) as total FROM invoices");
        $stats['total_paid'] = $stmt->fetch()['total'] ?? 0;
        
        // Lucro/Prejuízo total
        $stats['total_profit'] = $stats['total_received'] - $stats['total_paid'];
        
        // Faturas por status
        $stmt = $this->db->query("SELECT status, COUNT(*) as count FROM invoices GROUP BY status");
        $statusCounts = $stmt->fetchAll();
        foreach ($statusCounts as $status) {
            $stats['status_' . strtolower($status['status'])] = $status['count'];
        }
        
        // Faturas com vencimento próximo (7 dias)
        $stmt = $this->db->query("SELECT COUNT(*) as count FROM invoices WHERE due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND status = 'SENT'");
        $stats['due_soon'] = $stmt->fetch()['count'];
        
        // Clientes ativos (com faturas nos últimos 30 dias)
        $stmt = $this->db->query("SELECT COUNT(DISTINCT client_id) as count FROM invoices WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)");
        $stats['active_clients'] = $stmt->fetch()['count'];
        
        return $stats;
    }
}
?>
