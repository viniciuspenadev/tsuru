<?php
require_once __DIR__ . '/../config/database.php';

class Client {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function create($data) {
        $sql = "INSERT INTO clients (name, cnpj, address, city, state, zip, phone, email) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['name'],
            $data['cnpj'],
            $data['address'],
            $data['city'],
            $data['state'],
            $data['zip'],
            $data['phone'],
            $data['email']
        ]);
    }
    
    public function update($id, $data) {
        $sql = "UPDATE clients SET name = ?, cnpj = ?, address = ?, city = ?, 
                state = ?, zip = ?, phone = ?, email = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['name'],
            $data['cnpj'],
            $data['address'],
            $data['city'],
            $data['state'],
            $data['zip'],
            $data['phone'],
            $data['email'],
            $id
        ]);
    }
    
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM clients WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM clients WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function findAll($limit = 50, $offset = 0, $search = '') {
        $sql = "SELECT * FROM clients";
        $params = [];
        
        if (!empty($search)) {
            $sql .= " WHERE name LIKE ? OR cnpj LIKE ? OR email LIKE ?";
            $searchTerm = "%{$search}%";
            $params = [$searchTerm, $searchTerm, $searchTerm];
        }
        
        $sql .= " ORDER BY name ASC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function count($search = '') {
        $sql = "SELECT COUNT(*) as total FROM clients";
        $params = [];
        
        if (!empty($search)) {
            $sql .= " WHERE name LIKE ? OR cnpj LIKE ? OR email LIKE ?";
            $searchTerm = "%{$search}%";
            $params = [$searchTerm, $searchTerm, $searchTerm];
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'];
    }
}
?>
