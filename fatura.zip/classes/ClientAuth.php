<?php
require_once __DIR__ . '/../config/database.php';

class ClientAuth {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function authenticate($email, $password) {
        $stmt = $this->db->prepare("SELECT id, name, login_email, login_password, is_active FROM clients WHERE login_email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $client = $stmt->fetch();
        
        if ($client && password_verify($password, $client['login_password'])) {
            $_SESSION['client_id'] = $client['id'];
            $_SESSION['client_name'] = $client['name'];
            $_SESSION['client_email'] = $client['login_email'];
            $_SESSION['is_client'] = true;
            
            // Atualizar último login
            $this->updateLastLogin($client['id']);
            
            return true;
        }
        
        return false;
    }
    
    public function logout() {
        unset($_SESSION['client_id'], $_SESSION['client_name'], $_SESSION['client_email'], $_SESSION['is_client']);
        session_destroy();
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['client_id']) && isset($_SESSION['is_client']);
    }
    
    public function requireLogin() {
        if (!$this->isLoggedIn()) {
            header('Location: client-login.php');
            exit;
        }
    }
    
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT id, name, cnpj, address, city, state, zip, phone, email, login_email, last_login FROM clients WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function updateProfile($id, $data) {
        $sql = "UPDATE clients SET name = ?, address = ?, city = ?, state = ?, zip = ?, phone = ?, email = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['name'],
            $data['address'],
            $data['city'],
            $data['state'],
            $data['zip'],
            $data['phone'],
            $data['email'],
            $id
        ]);
    }
    
    public function updatePassword($id, $newPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("UPDATE clients SET login_password = ? WHERE id = ?");
        return $stmt->execute([$hashedPassword, $id]);
    }
    
    public function verifyPassword($id, $password) {
        $stmt = $this->db->prepare("SELECT login_password FROM clients WHERE id = ?");
        $stmt->execute([$id]);
        $client = $stmt->fetch();
        
        if ($client) {
            return password_verify($password, $client['login_password']);
        }
        
        return false;
    }
    
    private function updateLastLogin($id) {
        $stmt = $this->db->prepare("UPDATE clients SET last_login = CURRENT_TIMESTAMP WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    public function createLoginCredentials($clientId, $email, $password) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("UPDATE clients SET login_email = ?, login_password = ?, is_active = 1 WHERE id = ?");
        return $stmt->execute([$email, $hashedPassword, $clientId]);
    }
}
?>
