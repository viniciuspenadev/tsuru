<?php
// Este arquivo substitui o navbar.php anterior com um layout mais moderno e profissional
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? APP_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <?php if (isset($extraStyles)): ?>
        <?= $extraStyles ?>
    <?php endif; ?>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo-container">
                    <img src="https://delphiforwarding.com/wp-content/uploads/2022/01/Logo-01.svg" alt="Delphi Logo" class="logo">
                </div>
                <button class="sidebar-toggle d-md-none" id="sidebarToggle">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
            
            <div class="sidebar-user">
                <div class="user-avatar">
                    <i class="bi bi-person-circle"></i>
                </div>
                <div class="user-info">
                    <h5><?= htmlspecialchars($_SESSION['user_name']) ?></h5>
                    <span class="user-role">Administrador</span>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li class="nav-item <?= strpos($_SERVER['PHP_SELF'], 'dashboard.php') !== false ? 'active' : '' ?>">
                        <a href="dashboard.php" class="nav-link">
                            <i class="bi bi-speedometer2"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item <?= strpos($_SERVER['PHP_SELF'], 'clients.php') !== false ? 'active' : '' ?>">
                        <a href="clients.php" class="nav-link">
                            <i class="bi bi-people"></i>
                            <span>Clientes</span>
                        </a>
                    </li>
                    <li class="nav-item <?= strpos($_SERVER['PHP_SELF'], 'invoice-form.php') !== false ? 'active' : '' ?>">
                        <a href="invoice-form.php" class="nav-link">
                            <i class="bi bi-file-earmark-plus"></i>
                            <span>Nova Fatura</span>
                        </a>
                    </li>
                    <li class="nav-divider"></li>
                    <li class="nav-header">Relatórios</li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="bi bi-graph-up"></i>
                            <span>Faturamento</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="bi bi-calendar-check"></i>
                            <span>Vencimentos</span>
                        </a>
                    </li>
                    <li class="nav-divider"></li>
                    <li class="nav-item">
                        <a href="profile.php" class="nav-link">
                            <i class="bi bi-gear"></i>
                            <span>Configurações</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link">
                            <i class="bi bi-box-arrow-right"></i>
                            <span>Sair</span>
                        </a>
                    </li>
                </ul>
            </nav>
            
            <div class="sidebar-footer">
                <span>© <?= date('Y') ?> <?= APP_NAME ?></span>
                <span>v<?= APP_VERSION ?></span>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <!-- Mobile Header -->
            <header class="mobile-header d-md-none">
                <button class="sidebar-toggle" id="mobileSidebarToggle">
                    <i class="bi bi-list"></i>
                </button>
                <div class="mobile-logo">
                    <img src="assets/delphi-logo.png" alt="Delphi Logo" class="logo-small">
                    <span><?= APP_NAME ?></span>
                </div>
                <div class="mobile-actions">
                    <div class="dropdown">
                        <button class="btn btn-link dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">Perfil</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                        </ul>
                    </div>
                </div>
            </header>
            
            <!-- Page Content -->
            <div class="page-content">
                <?php if (isset($pageHeader)): ?>
                    <div class="page-header">
                        <div class="page-title">
                            <h1><?= $pageHeader ?></h1>
                            <?php if (isset($pageSubtitle)): ?>
                                <p class="text-muted"><?= $pageSubtitle ?></p>
                            <?php endif; ?>
                        </div>
                        <?php if (isset($pageActions)): ?>
                            <div class="page-actions">
                                <?= $pageActions ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($alertMessage)): ?>
                    <div class="alert alert-<?= $alertType ?? 'info' ?> alert-dismissible fade show" role="alert">
                        <?= $alertMessage ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Conteúdo da página será inserido aqui -->
                <?php if (isset($content)): ?>
                    <?= $content ?>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script>
        // Toggle sidebar on mobile
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggle = document.getElementById('mobileSidebarToggle');
            const sidebarClose = document.getElementById('sidebarToggle');
            const sidebar = document.querySelector('.sidebar');
            const appContainer = document.querySelector('.app-container');
            
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', function() {
                    appContainer.classList.toggle('sidebar-open');
                });
            }
            
            if (sidebarClose) {
                sidebarClose.addEventListener('click', function() {
                    appContainer.classList.remove('sidebar-open');
                });
            }
            
            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', function(event) {
                if (appContainer.classList.contains('sidebar-open') && 
                    !sidebar.contains(event.target) && 
                    !sidebarToggle.contains(event.target)) {
                    appContainer.classList.remove('sidebar-open');
                }
            });
        });
    </script>
    <?php if (isset($extraScripts)): ?>
        <?= $extraScripts ?>
    <?php endif; ?>
</body>
</html>
