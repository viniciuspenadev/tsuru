<?php
require_once '../config/config.php';
require_once '../classes/FinancialControl.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!verifyCSRFToken($input['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Token de segurança inválido']);
    exit;
}

try {
    $financial = new FinancialControl();
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        throw new Exception('ID inválido');
    }
    
    $result = $financial->deletePaidValue($id);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Valor pago excluído com sucesso']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao excluir valor pago']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
