<?php
require_once '../config/config.php';
require_once '../classes/InvoiceDocument.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

try {
    $invoiceId = intval($_GET['invoice_id'] ?? 0);
    
    if ($invoiceId <= 0) {
        throw new Exception('ID da fatura inválido');
    }
    
    $document = new InvoiceDocument();
    $documents = $document->getByInvoiceId($invoiceId);
    
    echo json_encode([
        'success' => true,
        'documents' => $documents
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
