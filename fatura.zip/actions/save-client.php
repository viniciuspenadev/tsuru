<?php
require_once '../config/config.php';
require_once '../classes/Client.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Token de segurança inválido']);
    exit;
}

try {
    $client = new Client();
    
    $data = [
        'name' => trim($_POST['name'] ?? ''),
        'cnpj' => trim($_POST['cnpj'] ?? ''),
        'address' => trim($_POST['address'] ?? ''),
        'city' => trim($_POST['city'] ?? ''),
        'state' => strtoupper(trim($_POST['state'] ?? '')),
        'zip' => trim($_POST['zip'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'email' => trim($_POST['email'] ?? '')
    ];
    
    // Validações
    if (empty($data['name'])) {
        throw new Exception('Nome é obrigatório');
    }
    
    if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Email inválido');
    }
    
    $id = intval($_POST['id'] ?? 0);
    
    if ($id > 0) {
        // Atualizar
        $result = $client->update($id, $data);
    } else {
        // Criar
        $result = $client->create($data);
    }
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Cliente salvo com sucesso']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao salvar cliente']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
