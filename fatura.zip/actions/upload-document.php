<?php
require_once '../config/config.php';
require_once '../classes/InvoiceDocument.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Token de segurança inválido']);
    exit;
}

try {
    $invoiceId = intval($_POST['invoice_id'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $category = $_POST['category'] ?? 'OUTROS';
    $notes = trim($_POST['notes'] ?? '');
    
    if ($invoiceId <= 0) {
        throw new Exception('ID da fatura inválido');
    }
    
    if (empty($description)) {
        throw new Exception('Descrição é obrigatória');
    }
    
    if (!isset($_FILES['document_file']) || $_FILES['document_file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Erro no upload do arquivo');
    }
    
    $document = new InvoiceDocument();
    $documentId = $document->upload($invoiceId, $_FILES['document_file'], $description, $category, $notes);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Documento anexado com sucesso',
        'document_id' => $documentId
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
