<?php
require_once '../config/config.php';
require_once '../classes/Invoice.php';
require_once '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Token de segurança inválido']);
    exit;
}

try {
    $invoiceId = intval($_POST['invoice_id'] ?? 0);
    $toEmail = filter_var($_POST['to_email'] ?? '', FILTER_SANITIZE_EMAIL);
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    if ($invoiceId <= 0 || empty($toEmail) || empty($subject) || empty($message)) {
        throw new Exception('Dados obrigatórios não informados');
    }
    
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Email inválido');
    }
    
    // Buscar dados da fatura
    $invoice = new Invoice();
    $invoiceData = $invoice->findById($invoiceId);
    
    if (!$invoiceData) {
        throw new Exception('Fatura não encontrada');
    }
    
    // Gerar PDF temporário
    $tempPdfPath = sys_get_temp_dir() . '/invoice_' . $invoiceId . '_' . time() . '.pdf';
    
    // Aqui você incluiria o código de geração do PDF similar ao generate-pdf.php
    // Por simplicidade, vou criar um PDF básico
    $pdfContent = "PDF da fatura " . $invoiceData['invoice_number'];
    file_put_contents($tempPdfPath, $pdfContent);
    
    // Configurar PHPMailer
    $mail = new PHPMailer(true);
    
    // Configurações do servidor
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME;
    $mail->Password = SMTP_PASSWORD;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = SMTP_PORT;
    $mail->CharSet = 'UTF-8';
    
    // Remetente
    $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
    
    // Destinatário
    $mail->addAddress($toEmail);
    
    // Conteúdo
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = nl2br(htmlspecialchars($message));
    
    // Anexar PDF
    if (file_exists($tempPdfPath)) {
        $filename = 'Fatura_' . $invoiceData['invoice_number'] . '.pdf';
        $mail->addAttachment($tempPdfPath, $filename);
    }
    
    // Enviar
    $mail->send();
    
    // Limpar arquivo temporário
    if (file_exists($tempPdfPath)) {
        unlink($tempPdfPath);
    }
    
    echo json_encode(['success' => true, 'message' => 'Email enviado com sucesso']);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
