<?php
require_once '../config/config.php';
require_once '../classes/FinancialControl.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Token de segurança inválido']);
    exit;
}

try {
    $financial = new FinancialControl();
    
    $invoiceId = intval($_POST['invoice_id']);
    $data = [
        'description' => trim($_POST['description']),
        'amount' => floatval($_POST['amount']),
        'currency' => $_POST['currency'],
        'received_date' => $_POST['received_date'],
        'payment_method' => trim($_POST['payment_method']),
        'bank_reference' => trim($_POST['bank_reference']),
        'notes' => trim($_POST['notes'])
    ];
    
    if (empty($data['description']) || $data['amount'] <= 0) {
        throw new Exception('Descrição e valor são obrigatórios');
    }
    
    $result = $financial->addReceivedValue($invoiceId, $data);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Valor recebido salvo com sucesso']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao salvar valor recebido']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
