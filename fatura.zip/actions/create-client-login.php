<?php
require_once '../config/config.php';
require_once '../classes/ClientAuth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Token de segurança inválido']);
    exit;
}

try {
    $clientId = intval($_POST['client_id'] ?? 0);
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';
    
    if ($clientId <= 0) {
        throw new Exception('ID do cliente inválido');
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Email inválido');
    }
    
    if (empty($password) || strlen($password) < 6) {
        throw new Exception('Senha deve ter pelo menos 6 caracteres');
    }
    
    $clientAuth = new ClientAuth();
    $result = $clientAuth->createLoginCredentials($clientId, $email, $password);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Credenciais de acesso criadas com sucesso']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao criar credenciais de acesso']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
