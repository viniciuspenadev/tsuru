<?php
require_once '../config/config.php';
require_once '../classes/InvoiceDocument.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!verifyCSRFToken($input['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Token de segurança inválido']);
    exit;
}

try {
    $documentId = intval($input['id'] ?? 0);
    
    if ($documentId <= 0) {
        throw new Exception('ID do documento inválido');
    }
    
    $document = new InvoiceDocument();
    $result = $document->delete($documentId);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Documento excluído com sucesso']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao excluir documento']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
