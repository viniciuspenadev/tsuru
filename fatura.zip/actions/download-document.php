<?php
require_once '../config/config.php';
require_once '../classes/InvoiceDocument.php';

if (!isLoggedIn()) {
    header('HTTP/1.0 403 Forbidden');
    exit('Acesso negado');
}

try {
    $documentId = intval($_GET['id'] ?? 0);
    
    if ($documentId <= 0) {
        throw new Exception('ID do documento inválido');
    }
    
    $documentClass = new InvoiceDocument();
    $document = $documentClass->findById($documentId);
    
    if (!$document) {
        throw new Exception('Documento não encontrado');
    }
    
    $filePath = $documentClass->getFilePath($documentId);
    
    if (!$filePath) {
        throw new Exception('Arquivo não encontrado no servidor');
    }
    
    // Definir headers para download
    header('Content-Type: ' . $document['mime_type']);
    header('Content-Disposition: attachment; filename="' . $document['original_filename'] . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
    
    // Enviar arquivo
    readfile($filePath);
    exit;
    
} catch (Exception $e) {
    header('HTTP/1.0 404 Not Found');
    exit('Erro: ' . $e->getMessage());
}
?>
